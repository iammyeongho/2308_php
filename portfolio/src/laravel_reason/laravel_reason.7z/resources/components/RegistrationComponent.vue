<template>
    <main class="registation-main">
        <form id="frmUserData">
        <div class="registation-main-center" :class="{ 'registation-main-center-none': regiflg1 }">
            <h2>회원 가입</h2>
            <label for="">이름</label>
            <input type="text" name="name">
            <label for="">성별</label>
            <div class="genderbox">
                <input type="radio" name="gender" value="0"> 남성
                <input type="radio" name="gender" value="1"> 여성
            </div>
            <label for="">생년월일</label>
            <input type="date" name="birthdate">
            <label for="">전화번호</label>
            <input type="tel" name="phone_number">
            <button type="button" @click="regiflg1=true; regiflg2=false;">다음</button>
        </div>
        <div class="registation-main-center" :class="{ 'registation-main-center-none': regiflg2 }">
            <h2>회원 가입</h2>
            <label for="">이메일</label>
            <input type="text" name="email">
            <label for="">비밀번호</label>
            <input type="password" name="password">
            <label for="">비밀번호 확인</label>
            <input type="password" name="password_chk">
            <button type="button" @click="regiflg1=false; regiflg2=true;">이전</button>
            <button @click="submitUserData()">회원가입</button>
        </div>
        </form>
    </main>
</template>
<script>
export default {
    name: 'RegistrationComponent',
    data() {
        return {
            regiflg1: false,
            regiflg2: true,

            // userData: {
            //     name: '',
            //     gender: '',
            //     birthdate: '',
            //     phone_number: '',
            //     email: '',
            //     password: '',
            //     password_chk: '',
            // },
        }
    },
    methods: {
        submitUserData() {
            const FRM = document.querySelector('#frmUserData');

            this.$store.dispatch('submitUserData', FRM);
        },
    },
}
</script>
<style>
    @import url('/css/common.css');
</style>